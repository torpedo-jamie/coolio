# coolio
coolio was created as an example of how to create your own Python package. That's all.
